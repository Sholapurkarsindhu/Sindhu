Hello Everyone 
below I am providing code to execute the file
Command: java -jar FermatsLastTheorem.jar
